/*
    socket.io 모듈
    웹 소켓을 이용하여 클라이언트에 실시간으로 데이터를 전송
    socket을 구현한 것으로 webSocket개발을 쉽게 할 수 있음

   프로그램끼리 데이터 통신
   os에게 데이터 전달 요청 -> lan카드를 통해 데이터 내보내기 -> ip로 컴퓨터 찾기 -> 네트워크 어댑터 도착 -> 컴퓨터에서 동작하는 프로그램 중 해당 포트 프로그램 찾기
   
   소켓
   두개의 응용프로그램이 네트워크 데이터를 주고받을 수 있게 연결하는 객체
   - 서버 소켓: 소켓을 가진 클라이언트가 나에게 연결하기 위한 목적으로 만드는 소켓
   - 일반 소켓: 실제 통신하는 소켓

   웹 소켓
   브라우저에서도 통신할 수 있는 소켓
   * 예전에는 소켓으로 통신프로그램구현했고 설치 후 사용. 웹에서 불가능
*/

/* 서버 소켓 */

const express = require('express');
const static = require('serve-static');
const path = require('path');
const logger = require('morgan');
const socketio = require('socket.io');
//서버에 두개 이상의 소켓이 연결하는걸 막는 보안정책때문에 ajax 기술로 소켓을 변환하는 모듈
//(실제 서버에서는 필요없는 모듈)
const cors = require('cors');

const app = express();

app.use(logger('dev'));
app.use(cors());
app.use('/public', static(path.join(__dirname, 'public')));

const server = app.listen(3000, () => {
    console.log('3000포트로 서버 실행 중');
});

//서버소켓을 만들 수 있는 객체
const io = socketio(server);



