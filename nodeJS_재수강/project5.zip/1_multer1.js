/*
    multer 모듈
    파일을 업로드하기 위한 익스프레스 미들웨어

    multer.diskStorage(
        destination: 파일을 저장할 디렉토리 설정
        filename: 파일이름을 설정(파일이름이 서로 중복되지 않게)
    )

    multer({
        storage: diskStorage 설정 객체
        limits: {
            files: 파일전송개수,
            fileSize: 전송가능한 파일용량
        }
    })

    serve-static 모둘
    특정 폴더를 요청에 의해 직접 파일에 접근할 수 있도록 기능을 제공하는 익스프레스 미들웨어
    리소스(이미지,..)의 실제 물리적인 디렉토리가 아닌 가상 디렉토리로 설정해주는 모듈

    morgan 모듈
    로그를 관리하기 위한 별도의 라이브러리 모듈

    path 모듈
    url 주소를 컨트롤하는 모듈

    moment.js
    https://momentjs.com/
    날짜와 시간을 쉽게 다룰 수 있도록 도와주는 라이브러리
*/


const express = require('express');
const bodyParser = require('body-parser');
const static = require('serve-static');
const path = require('path')
const multer = require('multer');
const logger = require('morgan');

const port = 3000;
const app = express();
const router = express.Router();

app.use(bodyParser.urlencoded({extended:false}));
//특정 폴더를 요청에 의해 직접 파일에 접근할 수 있도록 설정
//보통은 라우터로 url을 처리해야하는데 이를 이용하면 url에 직접 파일명을 작성하여 접근이 가능하다
app.use('/public', static(path.join(__dirname, 'public')));
app.use('/uploads', static(path.join(__dirname, 'uploads')));
app.use(logger('dev'));

const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, 'uploads');
    },
    filename: (req, file, callback) => {
        //extname(): 확장명 이름 가져옴
        //file.originalname: 업로드한 파일의 실제 파일명
        const extension = path.extname(file.originalname);//.jpg
        //basename(): 파일명에서 확장명만 제외
        const basename = path.basename(file.originalname, extension);//apple
        callback(null, basename + "_" + Date.now() + extension);//apple_1111.jpg
    }
});

const upload = multer({
    storage: storage,
    limits: {
        files: 1,
        fileSize: 1024*1024*100
    }
});

//multer객체.array(fieldName, maxCount): photo라는 name으로 넘어 오는 파일들을 받는다
router.route('/write').post(upload.array('photo', 1), (req, res) => {
    try{
        //넘오 온 파일
        const files = req.files;
        console.dir(req.files[0]);

        let originalname = '';
        let filename = '';
        let mimetype = '';
        let size = 0;

        if(Array.isArray(files)){
            console.log(`클라이언트에서 받아 온 파일 개수 : ${files.length}`);

            //받아 온 파일 정보 각각 저장
            for(let i = 0; i < files.length; i++){
                originalname = files[i].originalname;
                filename = files[i].filename;
                mimetype = files[i].mimetype;
                size = files[i].size;
            }
        }
        const title = req.body.title;

        res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
        res.write('<h2>이미지 업로드 성공</h2>');
        res.write('<hr/>');
        res.write(`<p>제목: ${title}</p>`)
        res.write(`<p>원본 파일명: ${originalname}</p>`)
        res.write(`<p>현재 파일명: ${filename}</p>`)
        res.write(`<p>MimeType: ${mimetype}</p>`)
        res.write(`<p>파일크기: ${size}</p>`)
        res.write(`<p><img src='/uploads/${filename}' width=200></p>`)
    }catch(e){
        console.log(e);
    }
});


app.use('/', router);

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중,,`);
});


