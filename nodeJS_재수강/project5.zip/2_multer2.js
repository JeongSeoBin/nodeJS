/* 메일로 이미지 전송 후 전송결과를 ejs파일로 보여주며 mongoDB에도 저장하기 */


const express = require('express');
const bodyParser = require('body-parser');
const static = require('serve-static');
const path = require('path')
const multer = require('multer');
const logger = require('morgan');
const nodemailer = require('nodemailer');
const fs = require('fs');
const ejs = require('ejs');
const MongoClient = require('mongodb').MongoClient;

const port = 3000;
const app = express();
const router = express.Router();

let database;

app.use(bodyParser.urlencoded({extended:false}));
app.use('/public', static(path.join(__dirname, 'public')));
app.use('/uploads', static(path.join(__dirname, 'uploads')));
app.use(logger('dev'));

const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, 'uploads');
    },
    filename: (req, file, callback) => {
        const extension = path.extname(file.originalname);
        const basename = path.basename(file.originalname, extension);
        callback(null, basename + "_" + Date.now() + extension);
    }
});

const upload = multer({
    storage: storage,
    limits: {
        files: 1,
        fieldSize: 1024*1024*100
    }
});

router.route('/mail').post(upload.array('photo', 1), (req, res) => {
    try{
        const files = req.files;
        let filename = "";
        if(Array.isArray(files)){
            for(let i=0; i<files.length; i++){
                filename = files[i].filename;
            }  
        }
        const toemail = req.body.toemail;
        const toname = req.body.toname;
        const title = req.body.title;
        const content = req.body.content;

        fs.readFile('uploads/' + filename, (err, data) => {
            const transporter = nodemailer.createTransport({
                service: 'Gmail',
                auth: {
                    user: 'wjdtjqls8194@gmail.com',
                    pass: 'hoho1010!@'
                },
                host: 'smtp.mail.com',
                port: '465'
            });
        
            const mailOptions = {
                from: '정서빈<wjdtjqls8194@gmail.com>',
                to: `${toname}<${toemail}>`,
                subject: title,
                text: content,
                 //파일을 메일로 보내기
                 attachments: [{'filename':filename, 'content':data}]
            };
        
            transporter.sendMail(mailOptions, (err, info) => {
                if(err){
                    console.log(err);
                }else{
                    console.log(info);

                    //메일 전송 후 전송결과를 몽고디비에 저장한다
                    if(database){
                        save(database, toemail, toname, title, content, (err, result) => {
                            if(err){
                                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                                res.write('<h2>전송정보 저장실패</h2>');
                                res.write('<p>오류가 발생했습니다</p>');
                                res.end();
                            }else{
                                if(result){
                                    //메일 전송 후 전송결과를 ejs페이지에 보여준다
                                    fs.readFile('public/result.ejs', 'utf8', (err, data) => {
                                        if(err){
                                            console.log(err);
                                        }else{
                                            res.writeHead(200, {'content-type':'text/html'});
                                            res.end(ejs.render(data, {
                                                "toname":toname,
                                                "toemail":toemail,
                                                "title":title,
                                                "content":content,
                                                "filename":filename
                                            }));
                                        }
                                    })
                                }else{
                                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                                    res.write('<h2>전송정보 저장실패</h2>');
                                    res.write('<p>메일전송정보를 저장하지 못했습니다</p>');
                                    res.end();
                                }
                            }
                        });
                    }else{
                        res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                        res.write('<h2>데이터베이스 연결 실패</h2>');
                        res.write('<p>mongoDB에 연결하지 못했습니다</p>');
                        res.end();
                    }
                }
            })
        })

    }catch(e){
        console.log(e);
    }
});

function save(database, toemail, toname, title, content, callback){
    const mail = database.collection('mail');

    mail.insertMany([{"toname":toname, "toemail":toemail, "title":title, "content":content}], (err, result) => {
        if(err){
            callback(err, null);
            return;
        }else{
            if(result.insertedCount > 0){
                callback(null, result);
            }else{
                callback(null,null);
            }
        }
    });
}


function connectionDB(){
    const databaseURL = "mongodb://localhost:27017";
    MongoClient.connect(databaseURL, (err, db) => {
        if(err){
            console.log(err);
        }else{
            const temp = db.db('frontend');
            database = temp;
            console.log('mongodb 데이터베이스 연결 성공');
        }
    });
}

app.use('/', router);

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중,,`);
    connectionDB();
});