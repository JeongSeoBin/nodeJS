const express = require('express');
//npmi express-session
const expressSession = require('express-session');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({extended:false}));
//expressSession객체 만들어서 미들웨어로 등록
app.use(expressSession({
    secret: '!@#$%^&*()',
    resave: false,
    saveUninitialized: true
}));

app.get('/login', (req, res) => {
    fs.readFile('login.html', 'utf8', (err, data) => {
        if(!err){
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data);
        }else{
            console.log(err);
        }
    });
});

app.post('/loginOk', (req, res) => {
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    console.log(userid);
    console.log(userpw);

    if(userid == 'admin' && userpw == '1234'){
        //로그인 성공시 아이디와 비밀번호를 세션에 저장
        req.session.member = {
            id: userid,
            userpw: userpw,
            isAuth: true
        };
        res.redirect('/welcome');
    }else{
        res.redirect('/fail')
    }
});

app.get('/welcome', (req, res) => {
    //session 조회
    if(req.session.member){
        console.log(req.session.member);

        fs.readFile('welcome.html', 'utf8', (err, data) => {
            if(!err){
                res.writeHead(200, {'content-type':'text/html'});
                res.end(data);
            }else{
                console.log(err);
            }
        });
    }else{
        res.redirect('/login');
    }
});

app.get('/fail', (req, res) => {
    fs.readFile('fail.html', 'utf8', (err, data) => {
        res.writeHead(200, {'content-type':'text/html'});
        res.end(data);
    });
});

app.get('/logout', (req, res) => {
    //세션 삭제
    req.session.destroy(() => {
        console.log('세션이 삭제되었습니다');
    });
    res.redirect('/login');
});

app.listen(port, () => {
    console.log('서버 실행 중');
});