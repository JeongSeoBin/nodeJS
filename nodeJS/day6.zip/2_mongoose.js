const express = require('express');
const bodyParser= require('body-parser');
const logger = require('morgan');
//npm i mongoose
const mongoose = require('mongoose');

const app = express();
const port = 3000;
const router = express.Router();

app.use(bodyParser.urlencoded({extended:false}));
app.use(logger('dev'));


let database;
let UserSchema;
let UserModel;
//데이터베이스 연결에 연결하는 메소드
function connectDB(){
    const url = "mongodb://localhost:27017/frontenddb";
    console.log('데이터베이스 연결 시도 중,, ')

    //몽구스의 여러 기능들을 다른 js파일 등 여러 곳에서 사용하기 위해
    //몽구스의 프로미스 객체를 global의 프로미스 객체로 사용
    mongoose.Promise = global.Promise;
    //mongoose를 사용해 데이터베이스를 연결
    mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true});
    //몽구스로 연결한 데이터베이스 객체를 가져온다
    database = mongoose.connection;

    //에러이벤트 발생시 콘솔에 출력하고 싶을때
    database.on('error', console.error.bind(console, "mongoose 연결실패"));
    //데이터베이스 연결 성공 이벤트 발생시
    database.on('open', () => {
        console.log('데이터베이스 연결 성공');
        //Schema(): 스키마를 정의하는 생성자
        UserSchema = mongoose.Schema({
            userid: String,
            userpw: String,
            name: String,
            gender: String
        });
        console.log("UserSchema 생성 완료");
        
        //스키마에 가상 메소드를 생성
        UserSchema.static('findAll', function(callback){
            console.log('findAll실행');
            //모든 list를 얻어와서 호출한 곳으로 err 혹은 result를 반환
            return this.find({}, callback)
            ;
        });

        //model(): 해당 스키마와 이름으로 컬렉션을 만든다
        //단 이름에 's'를 붙여 생성
        UserModel = mongoose.model('user', UserSchema);
        console.log('UserModel이 정의되었습니다')
    });
}

//http://localhost:3000/user/regist
router.route("/user/regist").post((req, res) => {
    console.log("user/regist 호출");
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    const name = req.body.name;
    const gender = req.body.gender;
    console.log(`userid:${userid}, userpw:${userpw}, name:${name}, gender:${gender}`);

    if(database){
        joinUser(database,userid,userpw,name,gender,(err, result) => {
            if(!err){
                if(result){
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원가입 성공</h2>');
                    res.end();
                }else{
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>화원가입 실패</h2>');
                    res.end();
                }
            }else{
                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>서버에러! 회원가입 실패</h2>');
                res.end();
            }
        });
    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();
    }
});

//http://localhost:3000/user/login
router.route("/user/login").post((req, res) => {
    console.log("/user/login");
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    console.log(`userid:${userid}, userpw:${userpw}`);

    if(database){
        loginUser(database,userid,userpw,(err, result) => {
            if(!err){
                if(result){
                    console.dir(result);
                    const name = result[0].name;
                    const gender = result[0].gender;

                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>로그인성공</h2>');
                    res.write(`<p>아이디 : ${userid}</p>`)
                    res.write(`<p>이름 : ${name}</p>`)
                    res.write(`<p>성별 : ${gender}</p>`)
                    res.end();

                }else{
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>로그인 실패</h2>');
                    res.end();
                }
            }else{
                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>서버오류!로그인 실패</h2>');
                res.end();
            }
        })

    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();

    }
});

//http://localhost:3000/user/list
router.route("/user/list").get((req, res) => {
    console.log("/user/list");

    if(database){
        UserModel.findAll((err, result) => {
            if(!err){
                if(result){
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원 리스트</h2>');
                    res.write('<div><ul>')
                    for(let i=0; i<result.length; i++){
                        const userid = result[i].userid;
                        const name = result[i].name;
                        const gender = result[i].gender;

                        res.write(`<li>${i}: ${userid} / ${name} / ${gender}</li>`);
                    }
                    res.write('</ul></div>')
                    res.end();

                }else{
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원정보 없음</h2>');
                    res.end();
                }
            }else{
                console.log('리스트 조회 실패')
            }
        })
    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();
    }
})



const joinUser = function(database,userid,userpw,name,gender,callback){
    console.log('joinUser() 호출');
    //사용자가 정의한 스키마로 만든 User모델(컬레션)에 document를 넣는다
    const users = new UserModel({userid:userid, userpw:userpw, name:name, gender:gender});
    users.save((err, result) => {
        if(!err){
            console.log('회원 document 추가');
            callback(null, result);
            return;
        }
        callback(err, null);
    });
}

const loginUser = function(database, userid, userpw, callback){
    console.log("loginUser() 호출");
    UserModel.find({userid:userid, userpw:userpw}, (err, result) => {
        if(!err){
            if(result.length > 0){
                console.log('일치하는 사용자 찾음');
                callback(null, result);
            }else{
                console.log('일치하는 사용자 없음');
                callback(null, null);
            }
            return
        }
        callback(err,null);
    });
}

app.use("/", router);

app.listen(port, () => {
    console.log('서버실행');
    connectDB();
});