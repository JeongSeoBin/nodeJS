const { listenerCount } = require('events');
const express = require('express');
const fs = require('fs');
//npm i jade
const jade = require('jade');

const app = express();
const port = 3000;

const router = express.Router();

router.route('/about').post((req, res) => {
    fs.readFile('./jade1.jade', 'utf-8', (err, data) => {
        if(!err){
            //jade파일을 html형식으로 변환하여 보내려면 첫째, compile을 한다
            const jd = jade.compile(data);
            res.writeHead(200, {'content-type':'text/html'});
            //둘째, 컴파일한 파일을 저장한 상수를 함수화하여 실행
            res.end(jd());
        }else{
            console.log(err);
        }
    });
});

app.use('/', router);
app.all('*', (req, res) => {
    res.status(404).send('<h2>페이지가 없습니다</h2>');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중,,`);
});