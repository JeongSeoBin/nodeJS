//npm i nodemailer
const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth:{
        user: 'wjdtjqls8194@gmail.com',
        pass: 'hoho1010!@'
    }, 
    host: 'smtp.mail.com',
    port: '465'
});

const mailOptions = {
    from: "정서빈<wjdtjqls8194@gmail.com>",
    to: "정서빈<wjdtjqls1010@naver.com>",
    subject: "제목",
    html: "<h2>안녕하세요 메일이 잘 가나요</h2><p style='color: deeppink'>정말 잘 가네요~~</p>"
};

transporter.sendMail(mailOptions, (err, info) => {
    transporter.close();
    if(err){
        console.log(err);
    }else{
        console.log(info);
    }
})