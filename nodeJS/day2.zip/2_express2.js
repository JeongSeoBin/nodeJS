/*
    Router 미들웨어
    사용자의 당야한 요청이 서버로 들오왔을때 use() 메소드로 설정한 미들웨어가 항상 호출되는 불편한 점이 있다
    이를 해결하고자 사용하는 미들웨어가 라우터 미들웨어이다
    요청 path를 이용하여 각 사용자에 따라 실행을 달리 한다

    라우터 객체 만들기
    const 라우터객체 = express.Router();
    라우터객체.route(요청패스).get(실행할 함수);
    라우터객체.route(요청패스).post(실행할 함수);

    익스프레스에 Router객체 저용
    app.use('/', 라우터객체);
*/

const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({extended: false}));

//라우터 객체 만들기
const router = express.Router();

//http://localhost:3000/member/login -> post
router.route('/member/login').post((req, res) => {
    console.log('/member/login 호출');
});
//http://localhost:3000/member/regist -> post
router.route('/member/regist').post((req, res) => {
    console.log('/member/regist 호출');
});
//http://localhost:3000/member/about -> get
router.route('/member/about').get((req, res) => {
    console.log('/member/about 호출');
});

//익스프레스에 라우터 미들웨어 추가
app.use('/', router);

//라우터에 해당되지 않는 나머지 요청이 들어오면
app.all('*', (req, res) => {
    res.status(404).send('<h2>페이지를 찾을 수 없습니다</h2>');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행중..`)
});