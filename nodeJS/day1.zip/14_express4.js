const express = require('express');
const app = express();
const port = 3000;

app.use((req, res) => {
    console.log('첫번째 미들웨어 실행');

    console.dir(req.header);
    //User-Agent : 사용자의 os나 브라우저와 같은 정보를 얻을 수 있다
    const userAgent = req.header('User-Agent');
    console.log(userAgent);

    //httP://localhost:3000?userid=apple
    //get방식의 변수값을 가져옴
    const paramName = req.query.userid;
    console.log(paramName);

    res.writeHead(200, {'content-type':'text/html;charset=utf-8'});
    res.write('<h2>익스프레스 서버에서 응답한 메시지입니다</h2>');
    res.write(`<p>User-Agent : ${userAgent}</p>`);
    res.write(`<p>paramName : ${paramName}</p>`);
    res.end();
});

app.listen(port, () => {
    console.log('서버 실행 중');
});