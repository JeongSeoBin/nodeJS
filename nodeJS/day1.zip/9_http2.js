const http = require('http');
const fs = require('fs');

http.createServer((req, res) => {
    //html파일을 fielSystem모듈로 읽어서 사용자에게 전달한다
    fs.readFile('test.html', (err, data) => {
        if(err){
            console.log(err);
        }else{
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data);
        }
    });
}).listen(3000, () => {
    console.log('서버 실행 중');
});