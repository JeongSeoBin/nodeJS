const express = require('express');
const app = express();
const port = 3000;

app.use((req, res) => {
    console.log('첫번째 미들웨어 실행');
    //다른 페이지로 이동
    res.redirect('https://www.naver.com');
});

app.listen(port, () => {
    console.log('서버 실행 중');
});