//mongoose모듈 안에 Schema 클래스
const { Schema } = require('mongoose');

//mongodb에서 암호화를 위한 모듈
//npm i crypto
const crypto = require('crypto');

Schema.createSchema = function(mongoose){
    console.log('createSchema() 호출');

    ////Schema(): 스키마를 정의하는 생성자
    const MemberSchema = mongoose.Schema({
        userid: {type:String, require:true, default:''},
        hashed_password:{type:String, default:''},
        name:{type:String, default:''},
        //암화화 시킬때 섞을 문자
        //crypto암호화는 복구가 가능한 암호화이며 복구할때 salt값이 필요하다
        salt:{type:String}, 
        age:{type:Number, default:0},
        //가입날짜
        created_at:{type:Date, default:Date.now()},
        updated_at:{type:Date, default:Date.now()},
        //제공자(facebook, 카카오툭, ..)
        provider:{type:String, default:''},
        //페이스북이 사용자 인증 후 돌려주는 해당 사용자를 가리키는 키값
        authToken:{type:String, default:''},
        //페이스북에게 사용자 인증 요청 후 돌려받는 사용자 정보
        facebook:{}
    });

    //virtual(): 스키마에 가상으로 필드를 만든다
    MemberSchema.virtual('userpw')
        //userpw 가상 필드의 set()메소드 호출시 자동으로 호출되는 익명함수
        //회원가입시 호출할 함수
        .set(function(userpw){
            console.log('set() 실행');
            //회원가입시 사용자가 입력한 비밀번호로 userpw필드 set
            //가상필드를 나타낼때 "_"를 붙인다
            this._userpw = userpw;
            this.salt = this.makeSalt();
            //회원가입시 사용자가 입력한 비밀번호를 암호화하여 db에 저장
            this.hashed_password = this.encryptPassword(userpw)
        })
        //userpw 가상 필드의 get()메소드 호출시 자동으로 호출되는 익명함수
        //로그인시 호출할 함수
        .get(function(){
            console.log('get() 실행 (필요없음)');
            //로그인시 사용자가 입력한 비밀번호를 암호화한 값과 userpw에 저장된 비밀번호를 get하여 암호화한 값과 비교
            return this._userpw;
        });

    //스키마 객체에 메소드 만드는 방법
    //method('함수명', 익명함수)
    MemberSchema.method('makeSalt', function(){
        console.log('makeSalt() 호출');
        return Math.round((new Date().valueOf() * Math.random())) + '';
    });

    MemberSchema.method('encryptPassword', function(plainText, inSalt){
        //로그인시
        //authenticate()에서 호출
        if(inSalt){
            console.log('encryptPassword() 호출 inSalt있음');
            //사용자가 입력한 비밀번호를 db에 저장된 salt값으로 암호화한다
            return crypto.createHmac('sha1', inSalt).update(plainText).digest('hex');
        //회원가입시
        //userpw set()에서 호출
        }else{
            console.log('encryptPassword() 호출 inSalt 없음')
            //사용자가 입력한 비밀번호를 방금 만든 salt값으로 암호화한다
            //입력한 패스워드 1234 -> salt에 저장된 값을 가져와서 sha1암호화를 통해 1234를 섞어줌 -> 16진수로 변환
            return crypto.createHmac('sha1', this.salt).update(plainText).digest('hex');
        }
    });

    MemberSchema.method('authenticate', function(plainText, inSalt, hashed_password){
        if(inSalt){
            console.log('authenticate() 호출 inSalt있음');
            //로그인시 입력한 비번을 암호화한것과 기존 암호화 비번과 비교
            return this.encryptPassword(plainText, inSalt) == hashed_password;
        }else{
            console.log('authenticate() 호출 inSalt없음 (필요없음)');
            return this.encryptPassword(plainText) == this.hashed_password;
        }
    });  

    //save()호출되기전 작업 작성
    MemberSchema.pre('save', (next) => {
        //다음으로 넘긴다 -> save호출
        if(!this.isNew) return next();
        if(!validatePresenceOf(this.userpw)){
            next(new Error("유효하지 않은 패스워드입니다"))
        }else{ 
            next();
        }
    });

    const validatePresenceOf = function(value){
        //데이터 여부 확인
        return value && value.length;
    }

    console.log('MemberSchema 정의 완료');
    return MemberSchema;
}

module.exports = Schema;