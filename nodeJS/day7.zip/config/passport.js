const local_signup = require('./passport/local_signup');
const local_login = require('./passport/local_login');
const facebook = require('./passport/facebook');

module.exports = function(app, passport){
    console.log('config/passport 호출');

    //serializeUser(): 사용자 정보 객체를 SESSION에 아이디로 저장
    passport.serializeUser((user, done) => {
        console.log('serializeUser() 호출', user);
        //id만 세션에 저장
        //done(null, user.id)
        //user객체를 세션에 저장
        done(null, user);
    })

    //deserializeUser(): 세션에 저장한 아이디(객체)를 통해 사용자 정보 객체를 불러옴
    //passport.session() 미들웨어가 호출하고 조회한 정보는 req.user에 저장
    passport.deserializeUser((user, done) => {
        console.log('deserializeUser() 호출', user);
        done(null, user);
    })

    passport.use('local-signup', local_signup);
    passport.use('local-login', local_login);
    passport.use('facebook', facebook(app, passport));
}