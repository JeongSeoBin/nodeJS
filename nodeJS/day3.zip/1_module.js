const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

//express 엔진에 특정 템플릿 엔진을 탑재
app.engine('html', require('ejs').renderFile);
app.use(bodyParser.urlencoded({extended: false}));

//사용자 정의 모듈에서 같은 웹서버를 사용할 수 있도록 웹서버를 넘겨준다
const module1 = require('./router/module1')(app, fs);

app.listen(port, () => {
    console.log('서버 실행중,,');
});
