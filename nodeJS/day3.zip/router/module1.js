// 1_module.js에서 띄운 웹 서버에서 module1.js 모듈을 불러다쓰고 있기때문에 여기서 새로운 웹서버를 띄우면 안된다
// const express = require('express');
// const app = express();

//사용자 정의 모듈
module.exports = (app, fs) => {

    //http://localhost:3000
    app.get('/', (req, res) => {
        //엔진에 ejs엔진을 탑재헸기때문에 res객체를 랜더링하여 보낼 수 있다
        //engine()을 통해 템플릿엔진을 등록하면 랜더링할 파일은 views폴더 안에 만들어야한다
        res.render('index.ejs', {
            length: 10
        });
    });

    //http://localhost:3000/about
    app.get('/about', (req, res) => {
        res.render('about.html');
    });

    //http://localhost:3000/list
    app.get('/list', (req, res) => {
        //__dirname : 현재 디렉토리
        fs.readFile('__dirname' + "/../data/member.json", "utf8", (err, data) => {
            if(!err){
                console.log(data);
                res.writeHead(200, {'content-type':'text/json;charset=utf-8'});
                res.end(data);
            }else{
                console.log(err);
            }
        });
    });

    //http://localhost:3000/getMember/apple
    //apple이 userid에 저장된다
    app.get('/getMember/:userid', (req, res) => {
        fs.readFile('__dirname' + "/../data/member.json", "utf8", (err, data) => {
            if(!err){
                //JSON.parse(data): json파일을 읽어들여 조작할 수 있는 객체 생성
                const member = JSON.parse(data);
                //res.json(): json형태로 사용자에게 전달해라
                //member[req.params.userid]: url요청으로 넘어 온 apple을 json파일에서 찾아라
                res.json(member[req.params.userid]); 
            }else{
                console.log(err);
            }
        });
    });

    //http://localhost:3000/joinMember/apple
    app.post('/joinMember/:userid', (req, res) => {
        const result = {};
        const userid = req.params.userid;
        //post로 넘어 온 body에 password가 없거나 name이 없으면
        if(!req.body["password"] || !req.body["name"]){
            //객체생성하고 전달
            result["success"] = 100;
            result["msg"] = "invalid request";
            res.json(result);
            return false;
        }

        fs.readFile(__dirname + "/../data/member.json", "utf-8", (err, data) => {
            const member = JSON.parse(data);
            //해당 아이디가 이미 있다면
            if(member[userid]){
                result["success"] = 101;
                result["msg"] = "duplicate";
                res.json(result);
                return false;
            }

            console.log(req.body);
            //post로 넘어 온 데이터를 통째로 member.json 파일에 userid이름 달아서 넣는다 
            member[userid] = req.body;
            //post데이터를 추가한 json파일을 string으로 바꿔 원본에 덮어쓴다
            fs.writeFile(__dirname + "/../data/member.json", JSON.stringify(member, null, '\t'), 'utf8', (err, data) => {
                if(!err){
                    result["success"] = 200;
                    result["msg"] = "success";
                    res.json(result);
                }else{
                    console.log(err);
                }
            });
        });
    });

    //http://localhost:3000/updateMember/apple
    app.put('/updateMember/:userid', (req, res) => {
        const result = {};
        const userid = req.params.userid;

        if(!req.body["password"] || !req.body["name"]){
            result["success"] = 100;
            result["msg"] = "invlaid request";
            res.json(resilt);
            return false;
        }

        fs.readFile(__dirname + "/../data/member.json", "utf8", (err, data) => {
            if(!err){
                const member = JSON.parse(data);
                member[userid] = req.body;

                fs.writeFile(__dirname + "/../data/member.json", JSON.stringify(member, null, '\t'), 'utf8', (err, data) => {
                    if(!err){
                        result["success"] = 200;
                        result["msg"] = "success";
                        res.json(result);
                    }else{
                        console.log(err);
                    }
                });
            }else{
                console.log(err);
            }
        });
    });

    //http://localhost:3000/deleteMember/berry
    app.delete('/deleteMember/:userid', (req, res) => {
        const result = {};

        fs.readFile(__dirname + "/../data/member.json", "utf8", (err,data) => {
            const member = JSON.parse(data);

            if(!member[req.params.userid]){
                result["success"] = 102;
                result["msg"] = "not found";
                res.json(result);
                return false;
            }

            //delete member[req.params.userid]
            delete member[req.params.userid];

            fs.writeFile(__dirname + "/../data/member.json", JSON.stringify(member, null, '\t'), 'utf8', (err, data) => {
                result["success"] = 200,
                result["msg"] = "success";
                res.json(result);
            });
        });
    });
}